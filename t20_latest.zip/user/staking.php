<?php include('header.php'); ?>

<style>
.stake-page{--s-green:var(--neon,#20e39a);--s-blue:#7b93ff;--s-gold:var(--gold,#d4af37);--s-muted:var(--text-secondary,#82908d)}
.stake-hero{position:relative;overflow:hidden;padding:22px;border-radius:20px;margin-bottom:14px}
.stake-hero:after{content:"";position:absolute;width:380px;height:200px;right:-100px;top:-100px;background:radial-gradient(circle,rgba(32,227,154,.13),transparent 68%);pointer-events:none}
.stake-hero-inner{position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:20px}
.stake-title{display:flex;align-items:center;gap:12px}.stake-title-icon{width:46px;height:46px;display:grid;place-items:center;border-radius:13px;color:var(--s-green);background:rgba(32,227,154,.09);border:1px solid rgba(32,227,154,.13);font-size:19px}
.stake-kicker{color:var(--s-green);font:800 9px var(--font-mono,monospace);letter-spacing:.14em;text-transform:uppercase}.stake-title h1{margin:2px 0 0;font-size:22px;font-weight:800}
.stake-copy{color:var(--s-muted);font-size:11px;margin:8px 0 0 58px}.stake-live{display:inline-flex;align-items:center;gap:7px;padding:8px 10px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.025);border-radius:10px;color:#aeb9b6;font:9px var(--font-mono,monospace)}
.stake-live-dot{width:6px;height:6px;border-radius:50%;background:var(--s-green);box-shadow:0 0 10px var(--s-green)}
.stake-metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px}.stake-metric{position:relative;overflow:hidden;padding:15px;border-radius:15px}
.stake-metric:after{content:"";position:absolute;right:-35px;bottom:-40px;width:100px;height:100px;border-radius:50%;background:rgba(32,227,154,.07)}.stake-metric.blue:after{background:rgba(123,147,255,.07)}.stake-metric.gold:after{background:rgba(212,175,55,.07)}
.stake-metric__label{color:var(--s-muted);font-size:9px;text-transform:uppercase;letter-spacing:.07em}.stake-metric__value{margin-top:7px;font:800 20px var(--font-mono,monospace)}.stake-metric__hint{color:var(--s-muted);font-size:9px;margin-top:3px}
.stake-metric__icon{position:absolute;right:13px;top:13px;width:32px;height:32px;display:grid;place-items:center;border-radius:9px;color:var(--s-green);background:rgba(32,227,154,.09)}.stake-metric.blue .stake-metric__icon{color:#9badff;background:rgba(123,147,255,.09)}.stake-metric.gold .stake-metric__icon{color:#d8b968;background:rgba(216,185,104,.09)}
.stake-workspace{padding:17px;border-radius:18px}.stake-workspace-head{display:flex;align-items:center;justify-content:space-between;gap:15px;margin-bottom:13px}.stake-workspace-title{display:flex;align-items:center;gap:10px}
.stake-workspace-icon{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;color:var(--s-green);background:rgba(32,227,154,.09)}.stake-workspace-title h5{margin:0;font-size:13px;font-weight:800}.stake-workspace-title p{margin:2px 0 0;color:var(--s-muted);font-size:9px}
.stake-head-actions{display:flex;align-items:center;gap:7px}.stake-count{padding:6px 9px;border-radius:8px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);color:var(--s-muted);font:9px var(--font-mono,monospace)}
.stake-table-head,.stake-row{display:grid;grid-template-columns:1.05fr 1fr 1fr 1fr 1fr 115px;gap:12px;align-items:center}.stake-table-head{padding:0 13px 8px;color:#5f6c69;font:800 8px var(--font-mono,monospace);text-transform:uppercase;letter-spacing:.07em}
.stake-row{min-height:70px;padding:10px 13px;margin-bottom:7px;border-radius:13px;border:1px solid rgba(255,255,255,.07);background:linear-gradient(100deg,rgba(255,255,255,.025),rgba(255,255,255,.012));transition:.2s;position:relative}.stake-row:before{content:"";position:absolute;left:0;top:13px;bottom:13px;width:2px;border-radius:4px;background:linear-gradient(180deg,var(--s-green),rgba(32,227,154,0))}
.stake-row:hover{transform:translateY(-1px);border-color:rgba(32,227,154,.18);background:linear-gradient(100deg,rgba(32,227,154,.035),rgba(255,255,255,.012))}
.stake-row-main small,.stake-cell small{display:block;color:#64716e;font:8px var(--font-mono,monospace);margin-bottom:3px}.stake-row-main strong{color:#f0f4f3;font-size:14px;font-weight:800}.stake-cell{color:#a8b2af;font-size:10px}.stake-cell strong{color:#dce3e1;font-size:10px}
.stake-amount{display:flex;align-items:center;gap:7px;font:800 11px var(--font-mono,monospace)}.stake-token{width:25px;height:25px;display:grid;place-items:center;border-radius:50%;background:linear-gradient(145deg,#27d9a0,#12966e);color:#fff;font-size:11px;font-weight:900}
.stake-status{display:inline-flex;align-items:center;gap:5px;width:max-content;padding:5px 8px;border-radius:20px;color:var(--s-green);background:rgba(32,227,154,.08);font:800 8px var(--font-mono,monospace)}.stake-status:before{content:"";width:4px;height:4px;border-radius:50%;background:currentColor;box-shadow:0 0 8px currentColor}.stake-status.completed{color:#8ca4ff;background:rgba(123,147,255,.08)}
.stake-action{display:flex;justify-content:flex-end}.stake-action .btn{min-width:105px;padding:7px 10px;border-radius:9px;font-size:9px;font-weight:800}
.stake-empty{display:none;min-height:220px;flex-direction:column;align-items:center;justify-content:center;text-align:center;border:1px dashed rgba(255,255,255,.08);border-radius:13px}.stake-empty-icon{width:46px;height:46px;display:grid;place-items:center;margin-bottom:10px;border-radius:13px;color:var(--s-green);background:rgba(32,227,154,.08);font-size:19px}.stake-empty h6{color:#fff;font-size:12px;margin-bottom:4px}.stake-empty p{color:var(--s-muted);font-size:9px;margin-bottom:12px}
.stake-modal .modal-content{background:#0b1715;border:1px solid rgba(255,255,255,.09);border-radius:18px;box-shadow:0 30px 90px rgba(0,0,0,.55)}.stake-modal .modal-header,.stake-modal .modal-footer{border-color:rgba(255,255,255,.07)}.stake-modal .modal-title{font-size:14px;font-weight:800}
.stake-form-box{padding:14px;border-radius:13px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.022)}.stake-input{min-height:48px;color:#fff!important;background:rgba(255,255,255,.035)!important;border:1px solid rgba(255,255,255,.09)!important}.stake-input:focus{border-color:rgba(32,227,154,.4)!important;box-shadow:0 0 0 .2rem rgba(32,227,154,.07)!important}
.stake-balance-line{display:flex;justify-content:space-between;align-items:center;margin-top:8px;color:var(--s-muted);font-size:9px}.stake-max{border:0;color:var(--s-green);background:rgba(32,227,154,.07);border-radius:6px;padding:4px 7px;font:800 8px var(--font-mono,monospace);cursor:pointer}
.stake-review{margin-top:12px;padding:12px;border-radius:11px;background:rgba(32,227,154,.035);border:1px solid rgba(32,227,154,.08)}.stake-review-row{display:flex;justify-content:space-between;padding:4px 0;color:var(--s-muted);font-size:9px}.stake-review-row strong{color:#fff;font:800 9px var(--font-mono,monospace)}
#stakeToast{position:fixed;right:18px;bottom:18px;z-index:99999;width:min(340px,calc(100vw - 30px))}.stake-toast{margin-top:7px;padding:11px 13px;border-radius:11px;border:1px solid rgba(255,255,255,.08);background:#0c1916;color:#eaf0ee;font-size:10px;box-shadow:0 16px 40px rgba(0,0,0,.35)}
@media(max-width:1000px){.stake-table-head,.stake-row{grid-template-columns:1fr 1fr 1fr 1fr 105px}.stake-table-head span:nth-child(4),.stake-row>.stake-cell:nth-child(4){display:none}}
@media(max-width:767px){.stake-hero-inner{align-items:flex-start;flex-direction:column}.stake-copy{margin-left:0}.stake-live{align-self:flex-start}.stake-metrics{grid-template-columns:1fr}.stake-workspace-head{align-items:flex-start;flex-direction:column}.stake-head-actions{width:100%;justify-content:space-between}.stake-table-head{display:none}.stake-row{grid-template-columns:1fr 1fr;gap:9px;padding:12px}.stake-row>.stake-cell:nth-child(4){display:block}.stake-action{justify-content:flex-start}}
@media(max-width:420px){.stake-workspace{padding:12px}.stake-row-main strong{font-size:12px}.stake-cell{font-size:8px}.stake-action .btn{min-width:92px;font-size:8px}}
</style>

<div class="dash-main stake-page">
    <div class="dash-topbar">
        <div class="dash-topbar__left">
            <button class="sidebar-toggle-btn" data-action="toggle-sidebar"><i class="bi bi-list fs-5"></i></button>
            <span class="network-badge d-none d-md-inline"><i class="bi bi-diagram-3 me-1"></i>BNB Smart Chain</span>
            <span class="network-badge d-none d-lg-inline"><i class="bi bi-patch-check me-1"></i>Contract Verified</span>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="wallet-pill d-flex"><span class="pulse-live" style="width:6px;height:6px;border-radius:50%;background:var(--neon);"></span><span class="connected_walletdash">0x7A...92F1</span></span>
        </div>
    </div>

    <div class="dash-content">
        <div class="glass-card stake-hero dash-reveal">
            <div class="stake-hero-inner">
                <div>
                    <div class="stake-title"><div class="stake-title-icon"><i class="bi bi-lock-fill"></i></div><div><div class="stake-kicker">Asset Growth</div><h1>Staking</h1></div></div>
                    <p class="stake-copy">Stake your OLD TOKEN directly on-chain and track all your staking activity in one place.</p>
                </div>
                <div class="stake-live"><span class="stake-live-dot"></span>STAKING ACTIVE</div>
            </div>
        </div>

        <div class="stake-metrics">
            <div class="glass-card stake-metric dash-reveal"><div class="stake-metric__label">Total Staked</div><div class="stake-metric__value" id="stakeTotal">0 OLD</div><div class="stake-metric__hint">Across all blockchain stakes</div><div class="stake-metric__icon"><i class="bi bi-layers"></i></div></div>
            <div class="glass-card stake-metric blue dash-reveal"><div class="stake-metric__label">Active Stakes</div><div class="stake-metric__value" id="stakeActive">0</div><div class="stake-metric__hint">Currently running</div><div class="stake-metric__icon"><i class="bi bi-activity"></i></div></div>
            <div class="glass-card stake-metric gold dash-reveal"><div class="stake-metric__label">Total Rewards</div><div class="stake-metric__value" id="stakeRewards">0 OLD</div><div class="stake-metric__hint">Total capital claimed</div><div class="stake-metric__icon"><i class="bi bi-graph-up-arrow"></i></div></div>
        </div>

        <div class="glass-card stake-workspace dash-reveal">
            <div class="stake-workspace-head">
                <div class="stake-workspace-title"><div class="stake-workspace-icon"><i class="bi bi-clock-history"></i></div><div><h5>Stake History</h5><p>Review your previous and active OLD TOKEN staking positions.</p></div></div>
                <div class="stake-head-actions"><div class="stake-count"><span id="stakeHistoryCount">0</span> Stakes</div><button type="button" class="btn btn-veri-primary btn-sm" onclick="STAKING_PAGE.openModal()"><i class="bi bi-plus-circle me-1"></i>Stake Now</button></div>
                <div class="stake-head-actions"><button type="button" class="btn btn-veri-primary btn-sm" onclick="STAKING_PAGE.claimOldToken()"><i class="bi bi-gift me-1"></i>Claim Old Token</button></div>

            </div>

            <div class="stake-table-head"><span>Stake</span><span>Amount</span><span>Start Date</span><span>Remaining</span><span>Status</span><span>Action</span></div>
            <div id="stakeList"></div>

            <div id="stakeEmpty" class="stake-empty">
                <div class="stake-empty-icon"><i class="bi bi-lock"></i></div><h6>No staking history</h6><p>Start your first stake to see it appear here.</p>
                <button type="button" class="btn btn-veri-primary btn-sm" onclick="STAKING_PAGE.openModal()"><i class="bi bi-plus-circle me-1"></i>Stake Now</button>
            </div>

            <div class="phgh-info-pro mt-2"><i class="bi bi-shield-check"></i><span>Blockchain staking is active. Stakes, claims, balances and history are loaded directly from the smart contract.</span></div>
        </div>
    </div>
</div>

<div class="modal fade stake-modal" id="stakeNowModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
        <div class="modal-header px-3 px-md-4 py-3"><h5 class="modal-title"><i class="bi bi-lock-fill me-2" style="color:var(--s-green)"></i>Stake Now</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
        <form id="stakeForm">
            <div class="modal-body"><div class="stake-form-box">
                <label class="small text-secondary mb-1">Amount of OLD TOKEN to stake</label>
                <div class="input-group"><input type="number" id="stakeAmount" class="form-control stake-input" min="1" step="0.01" placeholder="0.00" required><span class="input-group-text form-veri">OLD</span></div>
                <div class="stake-balance-line"><span>Available balance: <strong id="stakeAvailable">0 OLD</strong></span><button type="button" class="stake-max" onclick="STAKING_PAGE.setMax()">MAX</button></div>
                <div class="stake-review"><div class="stake-review-row"><span>Stake amount</span><strong id="reviewAmount">0 OLD</strong></div><div class="stake-review-row"><span>Claim Schedule</span><strong>30 Days / Claim</strong></div><div class="stake-review-row"><span>Max Claims</span><strong style="color:var(--s-green)">10</strong></div></div>
            </div></div>
            <div class="modal-footer px-3 px-md-4 py-2"><button type="button" class="btn btn-veri-outline btn-sm" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-veri-primary btn-sm"><i class="bi bi-check2-circle me-1"></i>Confirm Stake</button></div>
        </form>
    </div></div>
</div>

<div id="stakeToast"></div>

<?php include('footer.php'); ?>

<script>
/* ============================================================
   REAL OLD TOKEN STAKING
   Uses:
      oldToken.balanceOf()
      oldToken.allowance()
      oldToken.approve()
      mainContract.stakeOldToken()
      mainContract.getUserOldTokenStakes()
      mainContract.getOldTokenStake()
      mainContract.getOldTokenStakingState()
   ============================================================ */
(function () {
    const OLD_TOKEN_DECIMALS = 18;
    const MAX_CLAIMS = 10;
    const CLAIM_INTERVAL_DAYS = 30;

    function toast(msg, error = false) {
        if (typeof toastr !== "undefined") {
            error ? toastr.error(msg) : toastr.success(msg);
            return;
        }

        const w = document.getElementById("stakeToast");
        if (!w) return;

        const e = document.createElement("div");
        e.className = "stake-toast";
        e.innerHTML =
            '<i class="bi ' +
            (error ? "bi-exclamation-circle" : "bi-check-circle") +
            '" style="color:' +
            (error ? "#ff7f8b" : "#20e39a") +
            ';margin-right:7px"></i>' +
            String(msg).replace(/[&<>"']/g, function (c) {
                return {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#039;"
                }[c];
            });

        w.appendChild(e);
        setTimeout(function () {
            e.style.opacity = "0";
            setTimeout(function () { e.remove(); }, 220);
        }, 2600);
    }

    function money(value) {
        return Number(value || 0).toLocaleString(undefined, {
            minimumFractionDigits: 0,
            maximumFractionDigits: 6
        });
    }

    function formatDate(timestamp) {
        const ts = Number(timestamp || 0);
        if (!ts) return "--";

        const d = new Date(ts * 1000);

        return {
            date: d.toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }),
            time: d.toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit"
            })
        };
    }

    function shortAddr(address) {
        if (!address) return "--";
        return address.substring(0, 6) + "..." + address.substring(address.length - 4);
    }

    function tokenToNumber(value) {
        if (window.Web3 && Web3.utils && Web3.utils.fromWei) {
            return Number(Web3.utils.fromWei(String(value || "0"), "ether"));
        }
        return Number(value || 0) / 1e18;
    }

    function numberToWei(value) {
        /*
         * BigNumber is already used by the existing project.
         * Using string arithmetic here avoids JS floating-point issues.
         */
        if (window.Web3 && Web3.utils && Web3.utils.toWei) {
            return Web3.utils.toWei(String(value), "ether");
        }

        if (window.BigNumber) {
            return new BigNumber(String(value))
                .times(new BigNumber("1000000000000000000"))
                .integerValue(BigNumber.ROUND_DOWN)
                .toFixed(0);
        }

        throw new Error("Web3.js or BigNumber.js is required.");
    }

    async function getAccountSafe() {
        if (typeof getCurrentAccount === "function") {
            const a = await getCurrentAccount();
            if (a) return a;
        }

        if (window.ethereum) {
            const accounts = await ethereum.request({
                method: "eth_requestAccounts"
            });
            return accounts && accounts[0] ? accounts[0] : "";
        }

        return "";
    }

    async function getGasPriceSafe() {
        if (typeof getGas === "function") {
            return await getGas();
        }

        if (window.p && p.eth && p.eth.getGasPrice) {
            return await p.eth.getGasPrice();
        }

        return undefined;
    }

    function setButtonLoading(loading) {
        const btn = document.querySelector("#stakeForm button[type='submit']");
        if (!btn) return;

        if (loading) {
            btn.dataset.oldHtml = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML =
                '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
        } else {
            btn.disabled = false;
            btn.innerHTML =
                btn.dataset.oldHtml ||
                '<i class="bi bi-check2-circle me-1"></i>Confirm Stake';
        }
    }

    async function loadBalance() {
        try {
            const account = await getAccountSafe();

            if (!account) {
                $("#stakeAvailable").text("0 OLD");
                return 0;
            }

            const rawBalance = await oldToken.methods.balanceOf(account).call();
            const balance = tokenToNumber(rawBalance);

            $("#stakeAvailable").text(money(balance) + " OLD");
            return balance;
        } catch (error) {
            console.error("Old token balance error:", error);
            $("#stakeAvailable").text("0 OLD");
            return 0;
        }
    }

    async function loadStakingState() {
        try {
            const account = await getAccountSafe();

            if (!account) {
                resetMetrics();
                return;
            }

            const user = await mainContract.methods.userBase(account).call();

            if (!user.registered) {
                resetMetrics();
                return;
            }

            const state = await mainContract.methods
                .getOldTokenStakingState(account)
                .call();

            const totalStakes = Number(state.totalStakes || state[0] || 0);
            const totalOriginal = tokenToNumber(
                state.totalOriginalCapital !== undefined
                    ? state.totalOriginalCapital
                    : state[1]
            );
            const totalRemaining = tokenToNumber(
                state.totalRemainingCapital !== undefined
                    ? state.totalRemainingCapital
                    : state[2]
            );
            const totalClaimed = tokenToNumber(
                state.totalClaimedCapital !== undefined
                    ? state.totalClaimedCapital
                    : state[3]
            );

            /*
             * Active stake count is loaded from actual stake records,
             * because the contract's aggregate state does not expose
             * active count directly.
             */
            const ids = await mainContract.methods
                .getUserOldTokenStakes(account)
                .call();

            let activeCount = 0;

            for (let i = 0; i < ids.length; i++) {
                const stake = await mainContract.methods
                    .getOldTokenStake(ids[i])
                    .call();

                const active = stake.active !== undefined
                    ? stake.active
                    : stake[9];

                if (active) activeCount++;
            }

            $("#stakeTotal").text(money(totalOriginal) + " OLD");
            $("#stakeActive").text(activeCount);
            $("#stakeRewards").text(money(totalClaimed) + " OLD");
            $("#stakeHistoryCount").text(totalStakes);

            /*
             * Remaining capital is the actual currently locked capital.
             * Show it as available staking balance only in the review area
             * if the wallet balance cannot be loaded separately.
             */
            return {
                totalStakes,
                totalOriginal,
                totalRemaining,
                totalClaimed,
                activeCount
            };
        } catch (error) {
            console.error("Staking state error:", error);
        }
    }

    function resetMetrics() {
        $("#stakeTotal").text("0 OLD");
        $("#stakeActive").text("0");
        $("#stakeRewards").text("0 OLD");
        $("#stakeHistoryCount").text("0");
    }

    async function loadHistory() {
        const list = document.getElementById("stakeList");
        const empty = document.getElementById("stakeEmpty");

        if (!list || !empty) return;

        list.innerHTML = `
            <div class="text-center text-secondary py-5" style="font-size:10px">
                <span class="spinner-border spinner-border-sm me-2"></span>
                Loading staking history...
            </div>
        `;
        empty.style.display = "none";

        try {
            const account = await getAccountSafe();

            if (!account) {
                list.innerHTML = "";
                empty.style.display = "flex";
                return;
            }

            const user = await mainContract.methods.userBase(account).call();

            if (!user.registered) {
                list.innerHTML = `
                    <div class="text-center text-warning py-5" style="font-size:10px">
                        Wallet is not registered.
                    </div>
                `;
                return;
            }

            const ids = await mainContract.methods
                .getUserOldTokenStakes(account)
                .call();

            if (!ids || ids.length === 0) {
                list.innerHTML = "";
                empty.style.display = "flex";
                $("#stakeHistoryCount").text("0");
                return;
            }

            const rows = [];

            for (let i = ids.length - 1; i >= 0; i--) {
                const stakeId = ids[i];

                try {
                    const stake = await mainContract.methods
                        .getOldTokenStake(stakeId)
                        .call();

                    rows.push(renderStakeRow(stake));
                } catch (error) {
                    console.error("Stake #" + stakeId + " load error:", error);
                }
            }

            list.innerHTML = rows.join("");
            empty.style.display = rows.length ? "none" : "flex";
            $("#stakeHistoryCount").text(rows.length);

        } catch (error) {
            console.error("Stake history error:", error);

            list.innerHTML = `
                <div class="text-center text-danger py-5" style="font-size:10px">
                    Unable to load staking history.
                </div>
            `;
        }
    }

    function renderStakeRow(stake) {
        const id = stake.id !== undefined ? stake.id : stake[0];
        const user = stake.user !== undefined ? stake.user : stake[1];

        const originalRaw =
            stake.originalCapital !== undefined
                ? stake.originalCapital
                : stake[2];

        const remainingRaw =
            stake.remainingCapital !== undefined
                ? stake.remainingCapital
                : stake[3];

        const claimedRaw =
            stake.claimedCapital !== undefined
                ? stake.claimedCapital
                : stake[4];

        const claimCount =
            stake.claimCount !== undefined
                ? stake.claimCount
                : stake[5];

        const lastClaimTime =
            stake.lastClaimTime !== undefined
                ? stake.lastClaimTime
                : stake[6];

        const createTime =
            stake.createTime !== undefined
                ? stake.createTime
                : stake[7];

        const active =
            stake.active !== undefined
                ? stake.active
                : stake[9];

        const amount = tokenToNumber(originalRaw);
        const remaining = tokenToNumber(remainingRaw);
        const claimed = tokenToNumber(claimedRaw);

        const dt = formatDate(createTime);

        let statusHtml;

        if (active) {
            statusHtml =
                '<span class="stake-status">ACTIVE</span>';
        } else {
            statusHtml =
                '<span class="stake-status completed">COMPLETED</span>';
        }

        /*
         * Real claim action.
         * Contract requires 30 days from lastClaimTime before each claim.
         */
        const nowTs = Math.floor(Date.now() / 1000);
        const nextClaimTs = Number(lastClaimTime || 0) + (CLAIM_INTERVAL_DAYS * 24 * 60 * 60);
        const claimDue = active && Number(claimCount) < MAX_CLAIMS && nowTs >= nextClaimTs;

        let actionHtml;

        if (!active) {
            actionHtml = `
                <div>
                    <span class="text-secondary" style="font-size:8px">
                        <i class="bi bi-check-circle me-1"></i>Finished
                    </span>
                </div>
            `;
        } else if (claimDue) {
            actionHtml = `
                <div>
                    <button type="button"
                        class="btn btn-veri-primary btn-sm"
                        onclick="STAKING_PAGE.claimOldToken(${Number(id)})">
                        <i class="bi bi-gift me-1"></i>Claim
                    </button>
                    <span class="text-secondary d-block mt-1" style="font-size:8px">
                        ${Number(claimCount)} / ${MAX_CLAIMS} Claims
                    </span>
                </div>
            `;
        } else {
            const remain = Math.max(0, nextClaimTs - nowTs);
            const days = Math.floor(remain / 86400);
            const hours = Math.floor((remain % 86400) / 3600);
            const minutes = Math.floor((remain % 3600) / 60);

            actionHtml = `
                <div>
                    <span class="text-secondary" style="font-size:8px">
                        ${Number(claimCount)} / ${MAX_CLAIMS} Claims
                    </span>
                    <span class="d-block mt-1" style="font-size:8px;color:#64716e">
                        Next claim: ${days}d ${hours}h ${minutes}m
                    </span>
                </div>
            `;
        }

        return `
            <div class="stake-row">
                <div class="stake-row-main">
                    <small>STAKE #${escapeHtml(id)}</small>
                    <strong>${money(amount)} OLD</strong>
                </div>

                <div class="stake-amount">
                    <span class="stake-token">O</span>
                    ${money(amount)} OLD
                </div>

                <div class="stake-cell">
                    <strong>${escapeHtml(dt.date)}</strong>
                    <small>${escapeHtml(dt.time)}</small>
                </div>

                <div class="stake-cell">
                    <strong>${money(remaining)} OLD</strong>
                    <small>Remaining</small>
                </div>

                <div>
                    ${statusHtml}
                    <small style="display:block;color:#64716e;font-size:7px;margin-top:4px">
                        Claimed ${money(claimed)}
                    </small>
                </div>

                <div class="stake-action">
                    ${actionHtml}
                </div>
            </div>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? "").replace(/[&<>"']/g, function (c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[c];
        });
    }

    async function openModal() {
        $("#stakeAmount").val("");
        $("#reviewAmount").text("0 OLD");

        /*
         * Refresh real wallet balance every time modal opens.
         */
        await loadBalance();

        if (window.bootstrap) {
            bootstrap.Modal
                .getOrCreateInstance(document.getElementById("stakeNowModal"))
                .show();
        }
    }

    async function setMax() {
        const balance = await loadBalance();
        $("#stakeAmount").val(balance > 0 ? balance : "");
        updateReview();
    }

    function updateReview() {
        const amount = Number($("#stakeAmount").val() || 0);
        $("#reviewAmount").text(money(amount) + " OLD");
    }

    async function stakeNow() {
        const amountInput = String($("#stakeAmount").val() || "").trim();

        if (!amountInput || Number(amountInput) <= 0) {
            toast("Please enter a valid staking amount.", true);
            return;
        }

        const amountNumber = Number(amountInput);

        /*
         * Contract:
         * require(_amount / OLD_TOKEN_MAX_CLAIMS > 0)
         * OLD_TOKEN_MAX_CLAIMS = 10
         *
         * Therefore minimum is 10 OLD tokens.
         */
        if (amountNumber < MAX_CLAIMS) {
            toast("Minimum staking amount is 10 OLD TOKEN.", true);
            return;
        }

        setButtonLoading(true);

        try {
            const account = await getAccountSafe();

            if (!account) {
                toast("Please connect your wallet.", true);
                return;
            }

            const user = await mainContract.methods
                .userBase(account)
                .call();

            if (!user.registered) {
                toast("Your wallet is not registered.", true);
                return;
            }

            const rawAmount = numberToWei(amountInput);

            /*
             * Real OLD token balance check.
             */
            const rawBalance = await oldToken.methods
                .balanceOf(account)
                .call();

            if (window.BigNumber) {
                if (
                    new BigNumber(String(rawBalance)).lt(
                        new BigNumber(String(rawAmount))
                    )
                ) {
                    toast("Insufficient OLD TOKEN balance.", true);
                    return;
                }
            } else if (BigInt(rawBalance) < BigInt(rawAmount)) {
                toast("Insufficient OLD TOKEN balance.", true);
                return;
            }

            if (
                !confirm(
                    "You are staking " +
                    money(amountNumber) +
                    " OLD TOKEN.\n\nPress OK to continue."
                )
            ) {
                return;
            }

            showloader();
            $("#cover").css("display", "block");

            const gasPrice = await getGasPriceSafe();

            /*
             * STEP 1:
             * Approve OLD TOKEN to the main staking contract.
             */
            toast("Please confirm OLD TOKEN approval in your wallet.");

            const approveTx = oldToken.methods
                .approve(main_contract, rawAmount)
                .send(
                    Object.assign(
                        { from: account },
                        gasPrice ? { gasPrice: gasPrice } : {}
                    )
                );

            await approveTx;

            /*
             * STEP 2:
             * Call the actual smart-contract staking function.
             */
            toast("Approval successful. Confirm staking transaction.");

            const tx = mainContract.methods
                .stakeOldToken(rawAmount)
                .send(
                    Object.assign(
                        { from: account },
                        gasPrice ? { gasPrice: gasPrice } : {}
                    )
                );

            let txHash = "";

            if (tx && typeof tx.on === "function") {
                tx.on("transactionHash", function (hash) {
                    txHash = hash;
                    console.log("stakeOldToken tx:", hash);
                });
            }

            const receipt = await tx;

            console.log("stakeOldToken receipt:", receipt);

            /*
             * Since stakeOldToken increments oldTokenStakeCounter,
             * load the user's real stake IDs again instead of creating
             * a fake local ID.
             */
            let newStakeId = null;

            try {
                const ids = await mainContract.methods
                    .getUserOldTokenStakes(account)
                    .call();

                if (ids && ids.length) {
                    newStakeId = ids[ids.length - 1];
                }
            } catch (e) {
                console.warn("Could not read new stake ID:", e);
            }

            if (window.bootstrap) {
                bootstrap.Modal
                    .getOrCreateInstance(
                        document.getElementById("stakeNowModal")
                    )
                    .hide();
            }

            toast(
                newStakeId
                    ? "Stake #" + newStakeId + " created successfully."
                    : "Stake created successfully."
            );

            /*
             * Reload actual blockchain data.
             */
            await loadBalance();
            await loadStakingState();
            await loadHistory();

            if (txHash) {
                console.log("Stake transaction hash:", txHash);
            }

        } catch (error) {
            console.error("stakeOldToken error:", error);

            let message = "Staking transaction failed.";

            if (error && error.message) {
                if (
                    error.message.toLowerCase().includes("user denied") ||
                    error.message.toLowerCase().includes("user rejected")
                ) {
                    message = "Transaction was rejected in wallet.";
                } else if (
                    error.message.toLowerCase().includes("insufficient")
                ) {
                    message = "Insufficient OLD TOKEN or BNB for gas.";
                }
            }

            toast(message, true);
        } finally {
            $("#cover").css("display", "none");
            if (typeof hideloader === "function") hideloader();
            setButtonLoading(false);
        }
    }

    function getStakeField(stake, named, index) {
        return stake[named] !== undefined ? stake[named] : stake[index];
    }

    function getClaimableAmount(stake) {
        const original = getStakeField(stake, "originalCapital", 2);
        const remaining = getStakeField(stake, "remainingCapital", 3);
        const claimCount = Number(getStakeField(stake, "claimCount", 5) || 0);

        if (claimCount + 1 >= MAX_CLAIMS) {
            return String(remaining || "0");
        }

        // OLD_TOKEN_MONTHLY_BPS = 1000 and BPS = 10000 => 10%
        const originalBN = window.BigNumber
            ? new BigNumber(String(original || "0"))
            : null;

        if (originalBN) {
            let release = originalBN
                .times(1000)
                .div(10000)
                .integerValue(BigNumber.ROUND_DOWN);

            const remainingBN = new BigNumber(String(remaining || "0"));
            if (release.gt(remainingBN)) release = remainingBN;

            return release.toFixed(0);
        }

        // Fallback for environments without BigNumber.
        return String(Math.floor(Number(original || 0) * 0.10));
    }

    async function claimOldToken(stakeId = null) {
        let claimButton = null;

        try {
            const account = await getAccountSafe();

            if (!account) {
                toast("Please connect your wallet.", true);
                return;
            }

            const user = await mainContract.methods
                .userBase(account)
                .call();

            if (!user.registered) {
                toast("Your wallet is not registered.", true);
                return;
            }

            let selectedStake = null;

            /*
             * If a stake ID is supplied from the table, claim exactly that stake.
             * Otherwise find the first active stake whose 30-day claim is due.
             */
            if (stakeId !== null && stakeId !== undefined) {
                selectedStake = await mainContract.methods
                    .getOldTokenStake(String(stakeId))
                    .call();
            } else {
                const ids = await mainContract.methods
                    .getUserOldTokenStakes(account)
                    .call();

                const nowTs = Math.floor(Date.now() / 1000);

                for (let i = ids.length - 1; i >= 0; i--) {
                    const stake = await mainContract.methods
                        .getOldTokenStake(ids[i])
                        .call();

                    const active = getStakeField(stake, "active", 9);
                    const claimCount = Number(getStakeField(stake, "claimCount", 5) || 0);
                    const lastClaimTime = Number(getStakeField(stake, "lastClaimTime", 6) || 0);
                    const dueAt = lastClaimTime + (CLAIM_INTERVAL_DAYS * 24 * 60 * 60);

                    if (active && claimCount < MAX_CLAIMS && nowTs >= dueAt) {
                        selectedStake = stake;
                        break;
                    }
                }
            }

            if (!selectedStake) {
                toast("No OLD TOKEN claim is due right now.", true);
                return;
            }

            const selectedId = getStakeField(selectedStake, "id", 0);
            const active = getStakeField(selectedStake, "active", 9);
            const claimCount = Number(getStakeField(selectedStake, "claimCount", 5) || 0);
            const lastClaimTime = Number(getStakeField(selectedStake, "lastClaimTime", 6) || 0);
            const dueAt = lastClaimTime + (CLAIM_INTERVAL_DAYS * 24 * 60 * 60);
            const nowTs = Math.floor(Date.now() / 1000);

            if (!active) {
                toast("This stake is already completed.", true);
                return;
            }

            if (claimCount >= MAX_CLAIMS) {
                toast("All claims for this stake are completed.", true);
                return;
            }

            if (nowTs < dueAt) {
                const remain = dueAt - nowTs;
                const days = Math.floor(remain / 86400);
                const hours = Math.floor((remain % 86400) / 3600);
                toast(`Claim is not due yet. ${days}d ${hours}h remaining.`, true);
                return;
            }

            const claimableRaw = getClaimableAmount(selectedStake);
            const claimable = tokenToNumber(claimableRaw);

            if (claimable <= 0) {
                toast("Nothing to claim.", true);
                return;
            }

            const ok = confirm(
                "Claim " +
                money(claimable) +
                " OLD TOKEN reward for Stake #" +
                selectedId +
                "?\n\nPress OK to continue."
            );

            if (!ok) return;

            showloader();
            $("#cover").css("display", "block");

            toast("Please confirm the claim transaction in your wallet.");

            const gasPrice = await getGasPriceSafe();

            const tx = mainContract.methods
                .claimOldTokenReward(String(selectedId))
                .send(
                    Object.assign(
                        { from: account },
                        gasPrice ? { gasPrice: gasPrice } : {}
                    )
                );

            let txHash = "";

            if (tx && typeof tx.on === "function") {
                tx.on("transactionHash", function (hash) {
                    txHash = hash;
                    console.log("claimOldTokenReward tx:", hash);
                });
            }

            const receipt = await tx;

            console.log("claimOldTokenReward receipt:", receipt);

            toast(
                "Claim successful. " +
                money(claimable) +
                " OLD TOKEN reward processed."
            );

            await loadBalance();
            await loadStakingState();
            await loadHistory();

            if (txHash) {
                console.log("Claim transaction hash:", txHash);
            }

        } catch (error) {
            console.error("claimOldTokenReward error:", error);

            let message = "Claim transaction failed.";

            if (error && error.message) {
                const errMsg = error.message.toLowerCase();

                if (
                    errMsg.includes("user denied") ||
                    errMsg.includes("user rejected")
                ) {
                    message = "Transaction was rejected in wallet.";
                } else if (errMsg.includes("monthly claim not due")) {
                    message = "Monthly claim is not due yet.";
                } else if (errMsg.includes("insufficient new token reward")) {
                    message = "Contract has insufficient new token reward balance.";
                } else if (errMsg.includes("stake completed")) {
                    message = "This stake is already completed.";
                } else if (errMsg.includes("not stake owner")) {
                    message = "This stake does not belong to the connected wallet.";
                }
            }

            toast(message, true);
        } finally {
            $("#cover").css("display", "none");
            if (typeof hideloader === "function") hideloader();

            if (claimButton) {
                claimButton.disabled = false;
            }
        }
    }

    async function refresh() {
        try {
            await loadBalance();
            await loadStakingState();
            await loadHistory();
        } catch (e) {
            console.error("Staking refresh error:", e);
        }
    }

    document.addEventListener("DOMContentLoaded", function () {
        /*
         * Change modal labels from USDT/demo to actual OLD token.
         */
        $("#stakeAmount").attr("min", "10");
        $("#stakeAmount").attr("step", "0.000001");
        $(".stake-form-box .form-veri").text("OLD");
        $(".stake-review-row strong").first().attr("id", "reviewAmount");

        /*
         * Duration is not a fixed staking duration in the contract.
         * Claims are monthly, for maximum 10 claims.
         */
        const reviewRows = document.querySelectorAll(
            "#stakeNowModal .stake-review-row"
        );

        if (reviewRows[1]) {
            reviewRows[1].innerHTML =
                "<span>Claim Schedule</span>" +
                "<strong>30 Days / Claim</strong>";
        }

        if (reviewRows[2]) {
            reviewRows[2].innerHTML =
                "<span>Max Claims</span>" +
                '<strong style="color:var(--s-green)">10</strong>';
        }

        /*
         * Remove old frontend-preview message.
         */
        $(".phgh-info-pro").html(
            '<i class="bi bi-shield-check"></i>' +
            '<span>Blockchain staking is active. Stakes, balances and history are loaded directly from the smart contract.</span>'
        );

        $("#stakeAmount").on("input", updateReview);

        $("#stakeForm").on("submit", function (e) {
            e.preventDefault();
            stakeNow();
        });

        refresh();
    });

    window.STAKING_PAGE = {
        openModal,
        setMax,
        stakeNow,
        claimOldToken,
        refresh
    };
})();
</script>
